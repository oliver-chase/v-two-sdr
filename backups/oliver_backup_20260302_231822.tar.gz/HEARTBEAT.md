# Heartbeat Routine

## 1. Quick Checks (30 seconds)
- [ ] Human messages waiting? → Handle immediately
- [ ] Critical blockers? → Escalate
- [ ] SDR sends due? → Flag to Kiana

If nothing urgent, proceed to work mode.

## 2. Work Mode
1. Read `tasks/QUEUE.md`
2. Pick highest-priority Ready task that doesn't need Kiana
3. Do meaningful work on it
4. Update queue when done
5. If tokens remain, pick another task

**Token model for heartbeat:** Always Haiku. Never Sonnet/Opus.

## 3. Before Finishing
- [ ] Log to `memory/YYYY-MM-DD.md`
- [ ] Update `tasks/QUEUE.md`
- [ ] One message to Kiana if something significant

---

## Token Strategy
1. Kiana's direct requests — always first
2. Urgent/time-sensitive tasks
3. High-impact tasks (Fallow or V.Two)
4. Maintenance and cleanup

If approaching limit: wrap up, write handoff note in QUEUE.md, stop.

---

*Last updated: 2026-03-03*
