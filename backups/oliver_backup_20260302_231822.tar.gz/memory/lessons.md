# Lessons Learned

Rules written from past mistakes. Add: `## YYYY-MM-DD — [topic]` with the rule.

## 2026-03-03 — Credential safety
Never ask Kiana to paste tokens or API keys in chat. Dashboard setup only.

## 2026-03-03 — Doc hygiene
Never report a feature as "done ✅" without verifying it exists in code. Always grep first.

## 2026-03-03 — SKILL.md accuracy
A stale SKILL.md causes compounding confusion across sessions. Update it the moment a phase completes.
