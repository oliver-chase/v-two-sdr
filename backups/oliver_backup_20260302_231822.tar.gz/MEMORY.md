# MEMORY.md - Status & Context (Lean)

## FALLOW — PHASES 1-3 COMPLETE

**Phase:** Phase 4 planning (not started)
**Stack:** Express backend (port 3000) + Vite frontend (port 5173)
**Data:** JSON files — canonical_events.json — no database

### What's Built
- Phase 1: User submissions + venue monitoring ✅
- Phase 2: Free APIs (Meetup, Eventbrite, city calendars) + dedup ✅
- Phase 3: Full React UI (Tasks 1-8) ✅

### Phase 3 Components (all live)
AddVenueModal, EventCard, EventDetail, EventList, FilterPanel, ReviewQueue, SearchBar, SweepStatus

### Phase 4 — Not Started
See ROADMAP.md for full list. Top items:
- Location validation + radius filtering
- Google Calendar OAuth
- Status tab removal
- GDPR compliance
- Pagination

### Design System
Sage #B8A88C, Pink #D9908F, Green #6B8E6F, Cream #F9F7F4
Merriweather serif (titles) + Inter sans (body)

### Key Decisions Standing
- Favorites: localStorage (backend persistence is Phase 4)
- Data: JSON files, not SQL or Postgres
- Source filter: removed (user-hostile)
- Heartbeat: disabled
